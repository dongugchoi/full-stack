package ex01;

public class ex01 {
	public static void main(String[] args) {
		 int a[][]=new int [3][3];
		    init(a);
		
		for(int i=0; i<3;i++)
		      for(int j=0; j<3;j++)
		        a[i][j]=0;
	}
	
}
