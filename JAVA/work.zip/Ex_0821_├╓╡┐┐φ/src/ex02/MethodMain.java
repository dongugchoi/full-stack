package ex02;

public class MethodMain {
	public static void main(String[] args) {
		
	}
}
