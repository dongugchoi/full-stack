package ex03;

// 공통부분 추출하기

public class Unit {
	int x, y;
	void move(int x,int y) {/* 지징된 위치로 이동*/};
	void stop() {/* 현재 위치에 정지 */};
}

