package ex03;

//보병

public class Marine extends Unit{
	
	void stimPack() {/* 스팀팩을 사용한다.*/}
	
}
