package ex05_overriding;

public class CalPlus extends Calculator {
	

	 int getResult(int n1, int n2){
		return n1 + n2;
	
	}
}
