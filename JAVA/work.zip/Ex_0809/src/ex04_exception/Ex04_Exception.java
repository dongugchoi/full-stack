package ex04_exception;

public class Ex04_Exception {
	//ArithmeticException
	//정수를 0으로 나누려고 할 때 발생한다
	
		public static void main(String[] args) {
			
			int result = 10/0;
			
			System.out.println(result);
			
	}
}
