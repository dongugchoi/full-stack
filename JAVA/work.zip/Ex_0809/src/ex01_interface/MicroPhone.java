package ex01_interface;

public interface MicroPhone {
	public abstract void sing();
	//public abstract는 추상클래스이기때문에 메서드도 추상메서드로 간주해서
	//생략해도 상관없다.
	
	
}
