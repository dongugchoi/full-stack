package ex01_interface;

public interface Speaker {
	public abstract void music();
}
