package ex01_interface;

public interface BluetoothMIC extends MicroPhone, Speaker{
	
	abstract void connect();
	
}
