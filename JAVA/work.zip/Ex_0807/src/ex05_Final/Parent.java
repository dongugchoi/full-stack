package ex05_Final;

public final class Parent {
     
}
