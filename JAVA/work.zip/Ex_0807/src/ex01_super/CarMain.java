package ex01_super;

public class CarMain {
	public static void main(String[] args) {
		HybridWaterCar car = new HybridWaterCar(15,20,25);
		
		
		car.showCurrentGauge();

	}
}
