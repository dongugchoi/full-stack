package ex03_access;

import ex02_modifier.*; // modifier패키지의 모든 클래스를 import한다.

public class PublicB {
//	DefaultC c = new Default(); //default로 선언된 클래스는 다른 패키지에서 사용될 수 없다.
//	c.vaariableC = 20; //필드가 public으로 선언되어있음에도 불구하고 객체 생성자체가 안되기 떄문에 사용할수없다.
}
