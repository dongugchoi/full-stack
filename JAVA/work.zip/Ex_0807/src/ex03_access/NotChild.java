package ex03_access;

public class NotChild {
	void accessTest() {
//		parent p2 = new Parent();
//		p2.accessProtected();
	}
}
