package ex02_modifier;

public class Parent {
	protected void accessProtected() {
		System.out.println("Protected멤버에 접근하였습니다.");
	}
	
}
