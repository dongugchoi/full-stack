package ex02_modifier;

public class PublicB {
	public static void main(String[] args) {
		//PublicA의 객체를 생성하고 아무값이나 전달
		//pritA()메서드를 호출하세요
		
//		PublicA a = new PublicA(5);
//		a.printA();
	
	}
}
