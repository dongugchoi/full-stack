package ex04_extends;

public class Father extends Parent {

	
	@Override
	public void testMethod() {
		System.out.println("아빠 메서드 호출");
	}
	
}
