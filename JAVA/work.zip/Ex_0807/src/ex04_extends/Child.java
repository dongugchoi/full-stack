package ex04_extends;

//public class Child extends Father, Mother{
//	
//	//다중상속금지
//	
//	@Override
//	public void testMethod() {
//		super.testMethod();
//	}
//
//}
