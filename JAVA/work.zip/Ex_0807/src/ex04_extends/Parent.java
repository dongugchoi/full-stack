package ex04_extends;

public class Parent {
	public void testMethod() {
		System.out.println("부모메서드 호출");
	}
}
