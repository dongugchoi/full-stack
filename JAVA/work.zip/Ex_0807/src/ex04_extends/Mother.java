package ex04_extends;

public class Mother extends Parent{
	
	@Override
	public void testMethod() {
		System.out.println("엄마 메서드 호출");
	}
}
