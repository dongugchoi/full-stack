package ex04_lamda;

@FunctionalInterface
public interface MyFunction {
	void method(int num);
	
}
