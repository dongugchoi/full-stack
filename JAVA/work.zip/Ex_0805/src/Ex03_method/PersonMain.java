package Ex03_method;

public class PersonMain {

	public static void main(String[] args) {
		Person person = new Person();
		
		person.introduce("홍길동", 20);
		person.introduce("성춘향", 22);
		person.introduce("이몽룡", 23);

	}

}
