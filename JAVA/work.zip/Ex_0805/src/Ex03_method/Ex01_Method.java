package Ex03_method;

public class Ex01_Method {
	
	public static void main(String[] args) {
		//메서드의 호출은 반드시 메서드 안에서 해야한다.
		printHello();
	} // 메인 메서드의 끝
	
	//메서드는 반드시 메서드 밖에서 정의해야 한다. (메인 메서드 다음으로 작성)
	static void printHello() {
		System.out.println("안녕하세요.");
		System.out.println("반갑습니다.");
	}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
		
		
		
		
		
		
		
		
		
	
}
