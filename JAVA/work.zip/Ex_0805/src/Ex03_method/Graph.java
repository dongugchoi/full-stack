package Ex03_method;

import java.util.Random;

public class Graph {
		
	static String print(char ch, int num) {
		
		char a [] = new char[num];
		
		
		String str ="";
		for(int i = 0; i < a.length; i++) {
			str += a[i] = ch;
		}

		return str;

	}


	

	
	
	
}// 클래스의 끝
