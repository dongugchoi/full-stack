package Ex03_method;

public class TimesTable {
	static void showTable(int num) {
		for(int i = 1; i < 10; i++) {
			
				System.out.printf("%d * %d = %d\n",num,i,num*i);
		
		}// for의 끝
	}//showTable의 끝
	
}
