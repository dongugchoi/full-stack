package Ex03_method;

public class maxFinderMain {
	public static void main(String[] args) {
		MethodTest max = new MethodTest();
		
		int [] a = {1,2,3};
		
		
		
	}
}
