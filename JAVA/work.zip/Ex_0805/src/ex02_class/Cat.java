package ex02_class;

public class Cat {
	//main 적지 않음
	//main은 실행되는 클래스의 하나만 적는다.
}
