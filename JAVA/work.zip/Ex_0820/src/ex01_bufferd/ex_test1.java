package ex01_bufferd;

public class ex_test1 {
	public static void main(String[] args) {
		
		int x = 5;

		int y = x++;

		 

		System.out.println("x의 값 : " +x); // x : ?

		System.out.println("y의 값 : " +y); // y : ?
	}
}
