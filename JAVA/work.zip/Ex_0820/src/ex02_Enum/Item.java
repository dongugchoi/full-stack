package ex02_Enum;

public enum Item {START,STOP,EXIT}


