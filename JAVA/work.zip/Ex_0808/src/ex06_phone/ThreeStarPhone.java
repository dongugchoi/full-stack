package ex06_phone;

public class ThreeStarPhone extends Phone{

	@Override
	public void openingLogo() {
		System.out.println("★");
		
	}
	
}
