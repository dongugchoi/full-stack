package ex03_polymorphism;

public class Computer {

	public void powerOn() {
		System.out.println("컴퓨터가 켜졌습니다.");
	}
	
	public void powerOff() {
		System.out.println("컴퓨터가 종료됩니다.");
	}
	
}
