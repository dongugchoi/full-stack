package ex03_test;

public class PersonMain {
	public static void main(String[] args) {
		PersonManager pMger = new PersonManager();
		pMger.personMgr();
		
		
		
	}
}
