package ex02_print;

public class Print01 {
	public static void main(String[] args) {
		//print()메서드의 경우 소괄호 안에 있는 내용을 출력하되,
		//줄을 바꿔주지는 않는다.
		System.out.print("WelCome");
		System.out.print("Java World");
	}
}
