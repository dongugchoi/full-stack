package ex03_variable;

public class Ex_Variable03 {

	public static void main(String[] args) {
		//변수의 사용범위
		//모든 변수는 자신이 만들어진 중괄호 안에서만 사용할 수 있다.
		String favoriteFood;
		favoriteFood = "돈까스";
		
	}
	
//	favoriteFood = "돈까스"; 오류발생
		
	
}
