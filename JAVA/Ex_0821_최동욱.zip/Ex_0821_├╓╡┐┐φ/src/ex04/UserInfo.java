package ex04;

//아이디 패스워드 저장하기

public class UserInfo {
	private String id;
	private int pwd;
	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getPwd() {
		return pwd;
	}

	public void setPwd(int pwd) {
		this.pwd = pwd;
	}
	
	
	
	
}

