package ex02;

//온도구하기

public class Ex02_02 {
	
	
	//화씨를 섭씨로
	static Double fToc(Double num1) {
		return (num1-32)/1.8;
	}
	
	//섭씨를 화씨로
	static Double cTof(Double num2) {
		return 1.8 * num2 + 32;
	}
	
	
	
}
