package ex02;


//배열의 최대값을 찾는 maxFinder메서드 작성하기

public class MethodTest {

	public void maxFinder() {
		
	}
	
}
