package ex03;

//수송선

public class Dropship extends Unit{
	
	void load() {/*선택된 대상을 태운다.*/}
	void unloda() {/* 선택된 대상을 내린다. */}
	
}
