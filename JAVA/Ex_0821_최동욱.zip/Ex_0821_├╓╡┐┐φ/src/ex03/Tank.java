package ex03;

//탱크

public class Tank extends Unit{
	
	void changeMode() {/* 공격모드로 변환한다 */};
	
}
