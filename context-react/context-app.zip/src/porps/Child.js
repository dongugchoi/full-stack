import React from 'react';
import GrandChild from './GrandChild';

function Child() {
  return <GrandChild />;
}

export default Child;