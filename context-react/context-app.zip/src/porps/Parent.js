import React from 'react';
import Child from './Child';

function Parent({ user }) {
  return <Child />;
}

export default Parent;