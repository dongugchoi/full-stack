import { createContext } from "react";

export const BoardContext = createContext(null);
