package com.exam.dongugchoi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DongugchoiApplicationTests {

	@Test
	void contextLoads() {
	}

}
