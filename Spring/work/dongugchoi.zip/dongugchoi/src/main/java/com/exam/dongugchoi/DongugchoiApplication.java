package com.exam.dongugchoi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DongugchoiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DongugchoiApplication.class, args);
	}

}
